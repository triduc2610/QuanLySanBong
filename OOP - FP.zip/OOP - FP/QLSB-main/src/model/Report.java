package model;

public class Report {
  private double income;
  private int bookingCount;
  private int serviceCount;

  public Report(double income, int bookingCount, int serviceCount) {
    this.income = income;
    this.bookingCount = bookingCount;
    this.serviceCount = serviceCount;
  }

  public double getIncome() {
    return income;
  }

  public void setIncome(double income) {
    this.income = income;
  }

  public int getBookingCount() {
    return bookingCount;
  }

  public void setBookingCount(int bookingCount) {
    this.bookingCount = bookingCount;
  }

  public int getServiceCount() {
    return serviceCount;
  }

  public void setServiceCount(int serviceCount) {
    this.serviceCount = serviceCount;
  }

}
