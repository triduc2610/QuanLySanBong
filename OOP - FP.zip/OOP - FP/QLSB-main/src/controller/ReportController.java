package controller;

import model.Transaction;
import service.PitchService;
import service.TransactionService;
import view.TransactionListView;
import view.ReportView;
import model.Report;
import service.ReportService;
import java.sql.Date;
import javax.swing.*;
import com.toedter.calendar.JDateChooser;

public class ReportController {
    private TransactionListView transactionListView;
    private TransactionService transactionService = new TransactionService();
    private PitchService pitchService = new PitchService();
    private final ReportService reportService;
    private ReportView reportView;

    public ReportController() {
        this.reportService = new ReportService();
    }

    public ReportController(ReportView view) {
        this.reportService = new ReportService();
        this.reportView = view;
    }

    public ReportController(TransactionListView transactionListView) {
        this.reportService = new ReportService();
        this.transactionListView = transactionListView;
    }

    public void handlePitchFilter(String selectedPitch) {
        updateReportData(selectedPitch.equals("Tất cả") ? null : selectedPitch);
    }

    public void handleDateFilter(JDateChooser startDate, JDateChooser endDate) {
        if (startDate.getDate() == null || endDate.getDate() == null) {
            JOptionPane.showMessageDialog(reportView,
                    "Vui lòng chọn ngày bắt đầu và kết thúc!",
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (endDate.getDate().before(startDate.getDate())) {
            JOptionPane.showMessageDialog(reportView,
                    "Ngày kết thúc phải sau ngày bắt đầu!",
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // Convert java.util.Date to java.sql.Date
            java.sql.Date sqlStartDate = new java.sql.Date(startDate.getDate().getTime());
            java.sql.Date sqlEndDate = new java.sql.Date(endDate.getDate().getTime());

            System.out.println("DEBUG: Filtering data from " + sqlStartDate + " to " + sqlEndDate);

            // Get filtered data
            Object[][] data = reportService.getReportDataByDateRange(sqlStartDate, sqlEndDate);
            System.out.println("DEBUG: Retrieved " + (data != null ? data.length : 0) + " rows from database");

            // Update the view with filtered data
            updateViewData(data);

            System.out.println("DEBUG: Table and header panel updated");
        } catch (Exception ex) {
            System.out.println("ERROR: Exception during date filtering: " + ex.getMessage());
            ex.printStackTrace();
            JOptionPane.showMessageDialog(reportView,
                    "Có lỗi xảy ra khi lọc dữ liệu: " + ex.getMessage(),
                    "Lỗi",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void handleResetFilter() {
        loadInitialData();
    }

    private void updateReportData(String pitchId) {
        System.out.println("Updating report data for pitch: " + (pitchId == null ? "All" : pitchId));

        // Get updated data
        Report report = getSummaryStats(pitchId);
        Object[][] data = pitchId == null ? getAllReportData() : getReportDataByPitch(pitchId);

        // Update the view
        updateViewData(data);
    }

    private void loadInitialData() {
        System.out.println("Loading initial data...");
        updateReportData(null);
        System.out.println("Initial data loaded");
    }

    // Interface methods for view to call
    public void updateViewData(Object[][] data) {
        if (reportView instanceof ReportView) {
            ((ReportView) reportView).updateTableData(data);
            ((ReportView) reportView).updateHeaderPanel();
        }
    }

    public void LoadTransactionListData(int flag) {
        switch (flag) {
            case 0: // Load all transactions
                transactionListView.loadDataToTable(transactionService.getAllTransactions());
                break;
            case 1:
                transactionListView.loadDataToTable(transactionService.getTransactionsByCategory("BOOKING"));
                break;
            case 2:
                transactionListView.loadDataToTable(transactionService.getTransactionsByCategory("PRODUCT_SALE"));
                break;
            case 3:
                transactionListView.loadDataToTable(transactionService.getTransactionsByType("EXPENSE"));
                break;
            default:
                break;
        }
    }

    public void initdialog() {
        transactionListView.initdialog(pitchService.getAllPitches());
    }

    public boolean processSaveExpense() {
        Transaction transaction = transactionListView.getNewTransaction();
        System.out.println(transaction);
        if (transaction == null) {
            transactionListView.showMessage("Vui lòng nhập đầy đủ thông tin giao dịch!");
            return false;
        }
        if (transactionService.addTransaction(transaction)) {
            transactionListView.showMessage("Lưu giao dịch thành công!");
            LoadTransactionListData(3); // Refresh the expense list
            return true;
        } else {
            transactionListView.showMessage("Lưu giao dịch thất bại!");
            return false;
        }
    }

    public boolean processDeleteExpense(int id) {
        if (transactionService.deleteTransaction(id)) {
            transactionListView.showMessage("Xóa giao dịch thành công!");
            LoadTransactionListData(3);
            return true;
            // Refresh the expense list
        } else {
            transactionListView.showMessage("Xóa giao dịch thất bại!");
            return false;
        }
    }

    public Report getSummaryStats(String pitchId) {
        return reportService.getSummaryStats(pitchId);
    }

    public Object[][] getReportDataByDateRange(Date startDate, Date endDate) {
        return reportService.getReportDataByDateRange(startDate, endDate);
    }

    public Object[][] getAllReportData() {
        return reportService.getAllReportData();
    }

    public Object[][] getReportDataByPitch(String pitchId) {
        return reportService.getReportDataByPitch(pitchId);
    }
}
