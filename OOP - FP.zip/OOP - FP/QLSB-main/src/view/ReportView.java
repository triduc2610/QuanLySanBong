package view;

import java.awt.*;
import java.text.NumberFormat;
import java.util.Locale;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import com.toedter.calendar.JDateChooser;
import model.Report;
import controller.ReportController;
import java.sql.Date;

public class ReportView extends JPanel {
    private JPanel mainPanel;
    private Report report;
    private DefaultTableModel tableModel;
    private JTable reportTable;
    private NumberFormat currencyFormat;
    private ReportController controller;

    public ReportView() {
        controller = new ReportController(this);
        currencyFormat = NumberFormat.getInstance(new Locale("vi", "VN"));

        // Get initial report data
        report = controller.getSummaryStats(null);

        setLayout(new BorderLayout());
        createMainPanel();
        createHeaderPanel();
        createContentPanel();
        createTablePanel();

        add(mainPanel);
        loadInitialData();
    }

    private void createMainPanel() {
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(20, 20));
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        mainPanel.setBackground(Color.WHITE);
    }

    private void createHeaderPanel() {
        JPanel headerPanel = new JPanel(new GridLayout(1, 3, 20, 0));
        headerPanel.setBackground(mainPanel.getBackground());

        // Create summary boxes with dynamic colors for income
        Color incomeColor;
        if (report.getIncome() > 0) {
            incomeColor = new Color(46, 204, 113); // Green for positive
        } else if (report.getIncome() < 0) {
            incomeColor = new Color(231, 76, 60); // Red for negative
        } else {
            incomeColor = new Color(255, 179, 71); // Light orange for zero
        }

        headerPanel.add(createSummaryBox("Doanh thu", currencyFormat.format(report.getIncome()) + "đ",
                "Tổng doanh thu", incomeColor));
        headerPanel.add(createSummaryBox("Lượt đặt sân", report.getBookingCount() + "",
                "Tổng lượt sử dụng", new Color(52, 152, 219)));
        headerPanel.add(createSummaryBox("Dịch vụ", report.getServiceCount() + "",
                "Tổng dịch vụ sử dụng", new Color(155, 89, 182)));

        mainPanel.add(headerPanel, BorderLayout.NORTH);
    }

    private void createContentPanel() {
        JPanel contentPanel = new JPanel(new GridLayout(1, 2, 20, 0));
        contentPanel.setBackground(mainPanel.getBackground());

        // Left panel - Pitch Statistics
        JPanel pitchStatsPanel = createStyledPanel("Thống kê theo sân");
        JPanel pitchContent = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        pitchContent.setBackground(Color.WHITE);

        pitchContent.add(new JLabel("Chọn sân:"));
        JComboBox<String> pitchComboBox = new JComboBox<>(
                new String[] { "Tất cả", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" });
        pitchComboBox.setPreferredSize(new Dimension(150, 30));

        // Add action listener for filtering
        pitchComboBox.addActionListener(e -> {
            String selectedPitch = (String) pitchComboBox.getSelectedItem();
            controller.handlePitchFilter(selectedPitch);
        });

        pitchContent.add(pitchComboBox);
        pitchStatsPanel.add(pitchContent);

        // Right panel - Time Statistics
        JPanel timeStatsPanel = createStyledPanel("Thống kê theo thời gian");
        JPanel timeContent = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        timeContent.setBackground(Color.WHITE);

        timeContent.add(new JLabel("Từ:"));
        JDateChooser startDate = new JDateChooser();
        startDate.setPreferredSize(new Dimension(120, 30));
        startDate.setDateFormatString("dd/MM/yyyy");
        timeContent.add(startDate);

        timeContent.add(new JLabel("Đến:"));
        JDateChooser endDate = new JDateChooser();
        endDate.setPreferredSize(new Dimension(120, 30));
        endDate.setDateFormatString("dd/MM/yyyy");
        timeContent.add(endDate);

        JButton filterButton = createStyledButton("Lọc");
        filterButton.addActionListener(e -> controller.handleDateFilter(startDate, endDate));

        JButton resetButton = createStyledButton("Reset");
        resetButton.addActionListener(e -> {
            startDate.setDate(null);
            endDate.setDate(null);
            controller.handleResetFilter();
        });

        timeContent.add(filterButton);
        timeContent.add(resetButton);
        timeStatsPanel.add(timeContent);

        contentPanel.add(pitchStatsPanel);
        contentPanel.add(timeStatsPanel);

        mainPanel.add(contentPanel, BorderLayout.CENTER);
    }

    private void createTablePanel() {
        JPanel tablePanel = new JPanel(new BorderLayout(0, 10));
        tablePanel.setBackground(mainPanel.getBackground());

        // Table title
        JLabel tableTitle = new JLabel("Chi tiết báo cáo", SwingConstants.LEFT);
        tableTitle.setFont(new Font("Arial", Font.BOLD, 16));
        tablePanel.add(tableTitle, BorderLayout.NORTH);

        // Create table
        String[] columns = { "Hình thức", "Mục đích", "Số tiền", "Mã sân", "Thời gian" };
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        reportTable = new JTable(tableModel);
        reportTable.setRowHeight(30);
        reportTable.setFont(new Font("Arial", Font.PLAIN, 12));
        reportTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        reportTable.getTableHeader().setBackground(new Color(240, 240, 240));
        reportTable.setSelectionBackground(new Color(232, 241, 249));
        reportTable.setSelectionForeground(Color.BLACK);
        reportTable.setShowGrid(true);
        reportTable.setGridColor(new Color(230, 230, 230));

        // Add table to scroll pane
        JScrollPane scrollPane = new JScrollPane(reportTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(230, 230, 230)));
        tablePanel.add(scrollPane, BorderLayout.CENTER);

        // Add table panel to main panel
        mainPanel.add(tablePanel, BorderLayout.SOUTH);

        // Load initial data
        Object[][] data = controller.getAllReportData();
        System.out.println("Initial table data rows: " + (data != null ? data.length : 0));
        updateTableData(data);
    }

    private JPanel createSummaryBox(String title, String value, String subtitle, Color color) {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setBackground(color);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Title
        JLabel titleLabel = new JLabel(title);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Arial", Font.PLAIN, 14));

        // Value
        JLabel valueLabel = new JLabel(value);
        valueLabel.setForeground(Color.WHITE);
        valueLabel.setFont(new Font("Arial", Font.BOLD, 24));

        // Subtitle
        JLabel subtitleLabel = new JLabel(subtitle);
        subtitleLabel.setForeground(new Color(255, 255, 255, 200));
        subtitleLabel.setFont(new Font("Arial", Font.PLAIN, 12));

        // Layout
        JPanel textPanel = new JPanel(new GridLayout(3, 1, 5, 5));
        textPanel.setOpaque(false);
        textPanel.add(titleLabel);
        textPanel.add(valueLabel);
        textPanel.add(subtitleLabel);

        panel.add(textPanel, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createStyledPanel(String title) {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(230, 230, 230)),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 14));
        panel.add(titleLabel, BorderLayout.NORTH);

        return panel;
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(80, 30));
        button.setBackground(new Color(52, 152, 219));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    public void updateTableData(Object[][] data) {
        System.out.println("DEBUG: Updating table data...");
        if (data == null) {
            System.out.println("WARNING: Received null data in updateTableData");
            tableModel.setRowCount(0);
            return;
        }

        System.out.println("DEBUG: Clearing existing table data");
        tableModel.setRowCount(0);

        System.out.println("DEBUG: Adding " + data.length + " rows to table");
        for (Object[] row : data) {
            tableModel.addRow(row);
        }

        System.out.println("DEBUG: Table model now has " + tableModel.getRowCount() + " rows");
        reportTable.revalidate();
        reportTable.repaint();
    }

    public void updateHeaderPanel() {
        // Remove existing header panel
        Component oldHeader = ((BorderLayout) mainPanel.getLayout()).getLayoutComponent(BorderLayout.NORTH);
        if (oldHeader != null) {
            mainPanel.remove(oldHeader);
        }

        // Create new header panel with updated values
        JPanel headerPanel = new JPanel(new GridLayout(1, 3, 20, 0));
        headerPanel.setBackground(mainPanel.getBackground());

        // Get latest report data
        report = controller.getSummaryStats(null);

        // Create summary boxes with dynamic colors for income
        Color incomeColor;
        if (report.getIncome() > 0) {
            incomeColor = new Color(46, 204, 113); // Green for positive
        } else if (report.getIncome() < 0) {
            incomeColor = new Color(231, 76, 60); // Red for negative
        } else {
            incomeColor = new Color(255, 179, 71); // Light orange for zero
        }

        headerPanel.add(createSummaryBox("Doanh thu", currencyFormat.format(report.getIncome()) + "đ",
                "Tổng doanh thu", incomeColor));
        headerPanel.add(createSummaryBox("Lượt đặt sân", String.valueOf(report.getBookingCount()),
                "Tổng lượt sử dụng", new Color(52, 152, 219)));
        headerPanel.add(createSummaryBox("Dịch vụ", String.valueOf(report.getServiceCount()),
                "Tổng dịch vụ sử dụng", new Color(155, 89, 182)));

        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.revalidate();
        mainPanel.repaint();
    }

    private void loadInitialData() {
        System.out.println("Loading initial data...");
        controller.handleResetFilter();
        System.out.println("Initial data loaded");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new ReportView().setVisible(true);
        });
    }
}
