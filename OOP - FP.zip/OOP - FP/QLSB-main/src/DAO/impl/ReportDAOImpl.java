package DAO.impl;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Calendar;
import model.Report;
import java.text.NumberFormat;
import java.util.Locale;
import DAO.impl.DatabaseConnector;

import DAO.ReportDAO;

public class ReportDAOImpl implements ReportDAO {
  private NumberFormat currencyFormat;

  private void insertTestData() {
    System.out.println("Checking transactions table...");
    try (Connection conn = DatabaseConnector.connect("QuanLySanBong");
        Statement stmt = conn.createStatement()) {

      // First check if the table exists
      try {
        ResultSet rs = stmt.executeQuery("SELECT COUNT(*) as count FROM transactions");
        rs.next();
        int count = rs.getInt("count");
        System.out.println("Found " + count + " existing transactions");

        if (count == 0) {
          System.out.println("Inserting test transactions...");
          String insertSql = "INSERT INTO transactions (type, category, amount, description, pitch_Id) VALUES " +
              "('INCOME', 'BOOKING', 500000, 'Đặt sân 1', 1), " +
              "('INCOME', 'PRODUCT_SALE', 150000, 'Nước uống', 1), " +
              "('INCOME', 'BOOKING', 600000, 'Đặt sân 2', 2), " +
              "('INCOME', 'PRODUCT_SALE', 200000, 'Đồ ăn', 2), " +
              "('EXPENSE', 'MAINTENANCE', 300000, 'Sửa chữa sân 1', 1), " +
              "('EXPENSE', 'UTILITY', 100000, 'Tiền điện sân 2', 2)";

          int rowsInserted = stmt.executeUpdate(insertSql);
          System.out.println("Successfully inserted " + rowsInserted + " test transactions");

          // Verify the insertion
          rs = stmt.executeQuery("SELECT COUNT(*) as count FROM transactions");
          rs.next();
          System.out.println("Now have " + rs.getInt("count") + " total transactions");
        }
      } catch (SQLException e) {
        if (e.getMessage().contains("doesn't exist")) {
          System.out.println("Creating transactions table...");
          String createTableSql = "CREATE TABLE transactions (" +
              "id INT PRIMARY KEY AUTO_INCREMENT, " +
              "type VARCHAR(20), " +
              "category VARCHAR(50), " +
              "amount DOUBLE NOT NULL, " +
              "created_at DATETIME DEFAULT CURRENT_TIMESTAMP, " +
              "description TEXT, " +
              "pitch_Id INT" +
              ")";

          stmt.executeUpdate(createTableSql);
          System.out.println("Transactions table created successfully");

          // Try inserting data again
          insertTestData();
        } else {
          throw e;
        }
      }
    } catch (SQLException e) {
      System.out.println("Database error: " + e.getMessage());
      e.printStackTrace();
    }
  }

  public ReportDAOImpl() {
    currencyFormat = NumberFormat.getInstance(new Locale("vi", "VN"));
    insertTestData(); // Add some test data if table is empty
  }

  @Override
  public List<Report> findAll() {
    return null; // Not used in this implementation
  }

  @Override
  public Report findById(int id) {
    return null; // Not used in this implementation
  }

  @Override
  public boolean save(Report report) {
    return false; // Not used in this implementation
  }

  @Override
  public boolean update(Report report) {
    return false; // Not used in this implementation
  }

  @Override
  public boolean delete(int id) {
    return false; // Not used in this implementation
  }

  @Override
  public List<Report> getReportsByPitch(String pitchId) {
    return null; // Not used in this implementation
  }

  @Override
  public List<Report> getReportsByDateRange(Date startDate, Date endDate) {
    return null; // Not used in this implementation
  }

  @Override
  public Report getSummaryStats(String pitchId) {
    String sql = "SELECT " +
        "SUM(CASE WHEN type = 'INCOME' THEN amount " +
        "         WHEN type = 'EXPENSE' THEN -amount " +
        "         ELSE 0 END) as total_income, " +
        "COUNT(CASE WHEN category = 'BOOKING' THEN 1 END) as booking_count, " +
        "COUNT(CASE WHEN category = 'PRODUCT_SALE' THEN 1 END) as service_count " +
        "FROM transactions " +
        (pitchId != null ? "WHERE pitch_Id = ? " : "");

    System.out.println("Executing summary query: " + sql);
    try (Connection conn = DatabaseConnector.connect("QuanLySanBong");
        PreparedStatement stmt = conn.prepareStatement(sql)) {

      if (pitchId != null) {
        stmt.setString(1, pitchId);
      }

      ResultSet rs = stmt.executeQuery();
      if (rs.next()) {
        double totalIncome = rs.getDouble("total_income");
        int bookingCount = rs.getInt("booking_count");
        int serviceCount = rs.getInt("service_count");
        System.out.println(
            "Found summary data: Income=" + totalIncome + ", Bookings=" + bookingCount + ", Services=" + serviceCount);
        return new Report(totalIncome, bookingCount, serviceCount);
      }
    } catch (SQLException e) {
      System.out.println("Database error: " + e.getMessage());
      e.printStackTrace();
    }
    System.out.println("No summary data found, returning zeros");
    return new Report(0, 0, 0);
  }

  @Override
  public Object[][] getReportDataByDateRange(Date startDate, Date endDate) {
    ArrayList<Object[]> data = new ArrayList<>();
    String sql = "SELECT type, category, amount, pitch_Id, created_at, description " +
        "FROM transactions " +
        "WHERE created_at >= ? AND created_at <= ? " +
        "ORDER BY created_at DESC";

    System.out.println("DEBUG: Starting date range query...");
    System.out.println("DEBUG: Start date: " + startDate);
    System.out.println("DEBUG: End date: " + endDate);
    System.out.println("DEBUG: SQL Query: " + sql);

    try (Connection conn = DatabaseConnector.connect("QuanLySanBong");
        PreparedStatement stmt = conn.prepareStatement(sql)) {

      // Set time to start of day for start date and end of day for end date
      Calendar cal = Calendar.getInstance();

      cal.setTime(startDate);
      cal.set(Calendar.HOUR_OF_DAY, 0);
      cal.set(Calendar.MINUTE, 0);
      cal.set(Calendar.SECOND, 0);
      stmt.setTimestamp(1, new Timestamp(cal.getTimeInMillis()));

      cal.setTime(endDate);
      cal.set(Calendar.HOUR_OF_DAY, 23);
      cal.set(Calendar.MINUTE, 59);
      cal.set(Calendar.SECOND, 59);
      stmt.setTimestamp(2, new Timestamp(cal.getTimeInMillis()));

      System.out.println("DEBUG: Executing query with parameters:");
      System.out.println("DEBUG: Start timestamp: " + new Timestamp(cal.getTimeInMillis()));
      System.out.println("DEBUG: End timestamp: " + new Timestamp(cal.getTimeInMillis()));

      ResultSet rs = stmt.executeQuery();
      int rowCount = 0;

      while (rs.next()) {
        rowCount++;
        String type = rs.getString("type");
        String category = rs.getString("category");
        double amount = rs.getDouble("amount");
        String pitchId = rs.getString("pitch_Id");
        Timestamp date = rs.getTimestamp("created_at");

        System.out.println("DEBUG: Found row " + rowCount + ": Date=" + date +
            ", Type=" + type +
            ", Category=" + category +
            ", Amount=" + amount +
            ", PitchId=" + pitchId);

        Object[] row = {
            type,
            category,
            currencyFormat.format(amount) + "đ",
            pitchId,
            date
        };
        data.add(row);
      }
      System.out.println("DEBUG: Found " + rowCount + " transactions in date range");

      // Also update the summary statistics for this date range
      updateSummaryForDateRange(startDate, endDate);

    } catch (SQLException e) {
      System.out.println("ERROR in date range query: " + e.getMessage());
      e.printStackTrace();
    }

    return data.toArray(new Object[0][]);
  }

  private void updateSummaryForDateRange(Date startDate, Date endDate) {
    String sql = "SELECT " +
        "SUM(CASE WHEN type = 'INCOME' THEN amount " +
        "         WHEN type = 'EXPENSE' THEN -amount " +
        "         ELSE 0 END) as total_income, " +
        "COUNT(CASE WHEN category = 'BOOKING' THEN 1 END) as booking_count, " +
        "COUNT(CASE WHEN category = 'PRODUCT_SALE' THEN 1 END) as service_count " +
        "FROM transactions " +
        "WHERE created_at >= ? AND created_at <= ?";

    System.out.println("DEBUG: Updating summary for date range");
    try (Connection conn = DatabaseConnector.connect("QuanLySanBong");
        PreparedStatement stmt = conn.prepareStatement(sql)) {

      // Set time to start of day for start date and end of day for end date
      Calendar cal = Calendar.getInstance();

      cal.setTime(startDate);
      cal.set(Calendar.HOUR_OF_DAY, 0);
      cal.set(Calendar.MINUTE, 0);
      cal.set(Calendar.SECOND, 0);
      stmt.setTimestamp(1, new Timestamp(cal.getTimeInMillis()));

      cal.setTime(endDate);
      cal.set(Calendar.HOUR_OF_DAY, 23);
      cal.set(Calendar.MINUTE, 59);
      cal.set(Calendar.SECOND, 59);
      stmt.setTimestamp(2, new Timestamp(cal.getTimeInMillis()));

      ResultSet rs = stmt.executeQuery();

      if (rs.next()) {
        double totalIncome = rs.getDouble("total_income");
        int bookingCount = rs.getInt("booking_count");
        int serviceCount = rs.getInt("service_count");
        System.out.println("DEBUG: Date range summary - Income=" + totalIncome +
            ", Bookings=" + bookingCount +
            ", Services=" + serviceCount);
      }
    } catch (SQLException e) {
      System.out.println("ERROR updating summary for date range: " + e.getMessage());
      e.printStackTrace();
    }
  }

  @Override
  public Object[][] getAllReportData() {
    ArrayList<Object[]> data = new ArrayList<>();
    String sql = "SELECT type, category, amount, pitch_Id, created_at, description " +
        "FROM transactions " +
        "ORDER BY created_at DESC";

    System.out.println("Executing getAllReportData query: " + sql);
    try (Connection conn = DatabaseConnector.connect("QuanLySanBong");
        PreparedStatement stmt = conn.prepareStatement(sql)) {

      ResultSet rs = stmt.executeQuery();
      int rowCount = 0;
      while (rs.next()) {
        rowCount++;
        String type = rs.getString("type");
        String category = rs.getString("category");
        double amount = rs.getDouble("amount");
        String pitchId = rs.getString("pitch_Id");
        Timestamp date = rs.getTimestamp("created_at");

        System.out.println("Found row: Type=" + type + ", Category=" + category +
            ", Amount=" + amount + ", PitchId=" + pitchId + ", Date=" + date);

        Object[] row = {
            type,
            category,
            currencyFormat.format(amount) + "đ",
            pitchId,
            date
        };
        data.add(row);
      }
      System.out.println("Total rows found: " + rowCount);
    } catch (SQLException e) {
      System.out.println("Database error: " + e.getMessage());
      e.printStackTrace();
    }

    return data.toArray(new Object[0][]);
  }

  @Override
  public Object[][] getReportDataByPitch(String pitchId) {
    ArrayList<Object[]> data = new ArrayList<>();
    String sql = "SELECT type, category, amount, pitch_Id, created_at, description " +
        "FROM transactions " +
        "WHERE pitch_Id = ? " +
        "ORDER BY created_at DESC";

    try (Connection conn = DatabaseConnector.connect("QuanLySanBong");
        PreparedStatement stmt = conn.prepareStatement(sql)) {

      stmt.setString(1, pitchId);
      ResultSet rs = stmt.executeQuery();

      while (rs.next()) {
        Object[] row = {
            rs.getString("type"),
            rs.getString("category"),
            currencyFormat.format(rs.getDouble("amount")) + "đ",
            rs.getString("pitch_Id"),
            rs.getTimestamp("created_at")
        };
        data.add(row);
      }
    } catch (SQLException e) {
      e.printStackTrace();
    }

    return data.toArray(new Object[0][]);
  }

  private String formatCurrency(double amount) {
    return currencyFormat.format(amount) + "đ";
  }
}