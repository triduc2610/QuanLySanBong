package DAO;

import java.sql.*;
import java.util.List;
import model.Report;

public interface ReportDAO extends GenericDAO<Report> {
  List<Report> findAll();

  Report findById(int id);

  boolean save(Report report);

  boolean update(Report report);

  boolean delete(int id);

  List<Report> getReportsByPitch(String pitchId);

  List<Report> getReportsByDateRange(Date startDate, Date endDate);

  Report getSummaryStats(String pitchId);

  Object[][] getReportDataByDateRange(Date startDate, Date endDate);

  Object[][] getAllReportData();

  Object[][] getReportDataByPitch(String pitchId);
}