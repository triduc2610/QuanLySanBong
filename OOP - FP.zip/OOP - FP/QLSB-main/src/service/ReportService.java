package service;


import DAO.ReportDAO;
import DAO.impl.ReportDAOImpl;
import java.sql.Date;
import model.Report;

public class ReportService {
    private final ReportDAO reportDAO;

    public ReportService() {
        this.reportDAO = new ReportDAOImpl();
    }

    public Report getSummaryStats(String pitchId) {
        return reportDAO.getSummaryStats(pitchId);
    }

    public Object[][] getReportDataByDateRange(Date startDate, Date endDate) {
        return reportDAO.getReportDataByDateRange(startDate, endDate);
    }

    public Object[][] getAllReportData() {
        return reportDAO.getAllReportData();
    }

    public Object[][] getReportDataByPitch(String pitchId) {
        return reportDAO.getReportDataByPitch(pitchId);
    }
}
